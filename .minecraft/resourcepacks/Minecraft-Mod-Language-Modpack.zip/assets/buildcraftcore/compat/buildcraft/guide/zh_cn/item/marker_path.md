<chapter name="tile.pathMarkerBlock.name"/>
路径标对于<bold>一些东西</bold>和连接建筑者补件路径非常有用，哎呀，那个拼错了。我觉得只有填充机会用到它。
<chapter name="其他"/>
其他<bold>细节<underline>包括</underline>粗体<italic>文本</italic></bold>：

只是<blue>以</blue>防<bold>万</bold><green>一<red><italic>你没<underline>看</red>懂</italic></underline>⋯⋯</green>

<recipes_usages stack="buildcraftcore:marker_path"/>
<chapter name="信息"/>
<lore>
一些毫无意义的信息，不单是为了测试下一页逻辑而填充的很长的文字。
</lore>
<no_lore>
除非 lore 被关闭，否则这不应该出现在游戏中。
</no_lore>
<image src="buildcraftcore:textures/items/marker_path.png" width="64" height="64"/>
<image src="buildcraftlib:textures/items/guide_book.png" width="64" height="64"/>
<image src="buildcraftenergy:textures/gui/combustion_engine_gui.png"/>

<hint>
路径标真的没什么用。
</hint>
<new_page/>
为了确保新页面<italic>有效</italic>。
嗨，这应该在另一页上

<note id="mark_info">
嗨，这里是一个注释！
如果你想知道，这就是制作路径标的方法。
<recipes stack="buildcraftcore:marker_path" join="false"/>
</note>
